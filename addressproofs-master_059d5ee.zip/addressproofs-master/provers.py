"""
An address ownership proof library.
"""

import json
import secrets
import hashlib
from binascii import unhexlify
import base64

# pip3 install python-bitcoinlib
from bitcoin import SelectParams
from bitcoin.core import Hash160
from bitcoin.core.script import (
    CScript,
    CScriptOp,
    OP_0,
    OP_DUP,
    OP_HASH160,
    OP_EQUALVERIFY,
    OP_CHECKSIG,
    OP_CHECKMULTISIG,
)
from bitcoin.wallet import CBitcoinAddress, CBitcoinSecret, P2WPKHBitcoinAddress, P2WSHBitcoinAddress
from bitcoin.signmessage import BitcoinMessage, VerifyMessage, SignMessage
from bitcoin.core import (
    # hex to big-endian bytes
    x,
    # big-endian bytes to hex
    b2x,
)
from bitcoin.core.key import CPubKey

from web3.auto import w3
from eth_account.messages import encode_defunct
from sha3 import keccak_256 as keccak256
from rlp.codec import encode as rlp_encode

from solana.account import Account as SolanaAccount
from solana.publickey import PublicKey as SolanaPublicKey
import nacl.signing

# monero stuff
from monero_glue.xmr.crypto import (
    generate_signature as generate_monero_signature,
    check_signature as check_monero_signature,
    xmr_base58_addr_decode_check,
    decodeint,
    decodepoint,
    encodepoint,
    cn_fast_hash,
    b58_mnr,
)

# for zcash
from multicrypto.ecdsa import (
    sign_message as multicrypto_sign_message,
    verify_message as multicrypto_verify_message,
)
import multicrypto.ecdsa

from multicrypto.address import (
    convert_private_key_to_wif_format,
    convert_wif_private_key_to_address,
)

from multicrypto.coins import coins as multicrypto_coin_data

def monkeypatched_add_magic_prefix(message, coin):
    coin_name = coin['name'].capitalize()
    if coin_name == "Darkcoin":
        coin_name = "DarkCoin"
    prefix = '{} Signed Message:\n'.format(coin_name)
    return '{prefix_length}{prefix}{message_length}{message}'.format(
        prefix_length=chr(len(prefix)),
        prefix=prefix,
        message_length=chr(len(message)),
        message=message
    )
multicrypto.ecdsa.add_magic_prefix = monkeypatched_add_magic_prefix

def make_default_ownership_proof_message(shyftID, address):
    # TODO: make a better message template, and see what other Travel Rule
    # solutions use for this.
    message = b"I am shyftID=" + bytes(shyftID, "ascii") + b" and I own the address " + bytes(str(address), "ascii")
    hashed = hashlib.sha256(message)
    return hashed.hexdigest()

# TODO: use ethereum's hexbytes library?
def ethereum_address_to_bytes(address):
    if address[:2] == "0x":
        address = address[2:]
    return x(address)

def ethereum_bytes_to_address(some_bytes):
    return "0x" + b2x(some_bytes)

class MoneroAddressOwnership:

    _chain = "XMR-mainnet"
    _asset = "XMR"
    _address_type = "default" # TODO: does this address type have a formal name?

    def __init__(self, address: str, shyftID: str, wire_message: dict):
        self.address = address
        self.shyftID = shyftID
        self._verified = False
        self.signature = None

    def make_ownership_proof_message(self):
        #return make_default_ownership_proof_message(self.shyftID, self.address)
        message = b"I am shyftID=" + bytes(self.shyftID, "ascii") + b" and I own the address " + bytes(str(self.address), "ascii")
        return message

    def make_wire_message(self):
        message = {
            "chain": self._chain,
            "asset": self._asset,
            "address_type": self._address_type,

            "address": self.address,
            "shyftID": self.shyftID,
        }

        if self.signature != None:
            message["signature"] = self.signature

        return message

    # Just an example function for how to generate a valid signature. This
    # particular method takes a secret key in the form of a hex-encoded monero
    # encoded integer.
    def sign(self, seckey: str):
        # TODO: debug me
        # prepare the message
        ownership_proof_message = self.make_ownership_proof_message()
        hashed_ownership_proof_message = cn_fast_hash(ownership_proof_message)

        # prepare the secret key
        private_spend_key = decodeint(unhexlify(seckey))

        # sign
        (c, r, pub) = generate_monero_signature(hashed_ownership_proof_message, private_spend_key)

        # encode the signature
        signature = b2x(bytes(c) + bytes(r))
        signature = b58_mnr.b58encode(signature)
        signature = b"SigV1" + signature

        # decode into a string
        signature = signature.decode("ascii")

        verify = self.verify(signature)
        if not verify:
            raise Exception("Signing failed.")

        return signature

    def verify(self, signature: str):
        #if not self.is_address_valid()
        #    raise Exception("Invalid address.")

        original_signature = signature
        address = self.address

        # prepare the message that should have been signed
        ownership_proof_message = self.make_ownership_proof_message()
        hashed_ownership_proof_message = cn_fast_hash(ownership_proof_message)

        # decode the signature
        signature = signature[len("SigV1"):]
        signature = b58_mnr.b58decode(signature)
        c = decodeint(signature[:32])
        r = decodeint(signature[32:])
        (pub, version) = xmr_base58_addr_decode_check(address.encode())
        public_spend_key = decodepoint(pub)

        # try with the spend key
        verify = check_monero_signature(hashed_ownership_proof_message, c, r, public_spend_key)
        self._verified = verify

        if verify == True:
            self.signature = original_signature

        return verify

class EthereumMainnetExternallyOwnedAccountOwnership:

    _chain = "ETH-mainnet"
    _asset = None # no constraint
    _address_type = "EOA"

    # address === account
    def __init__(self, address: str, shyftID: str, wire_message: dict):
        self.address = str(address)
        self.shyftID = shyftID
        self._verified = False
        self.signature = None

    def make_ownership_proof_message(self):
        """
        Both the prover and the verifier need to construct the same message
        that they will be proving and verifying on. If the message differs in
        any way, then the proof will fail even if the prover has the secret
        key.
        """
        #return make_default_ownership_proof_message(self.shyftID, self.address)
        message = b"I am shyftID=" + bytes(self.shyftID, "ascii") + b" and I own the address " + bytes(str(self.address), "ascii")
        return message

    def make_wire_message(self):
        """
        The prover can use this function to generate a dictionary with
        information for the verifier to select which verifier to use for the
        given address. It also includes the signature.

        Over the wire the format of the message might be string-serialized json
        or some other format.
        """

        # ownership_proof_message can be reconstructed from these details and
        # therefore doesn't need to be sent over the wire.

        message = {
            "chain": self._chain,
            "asset": self._asset, # not constrained
            "address_type": self._address_type,
            "address": self.address,

            # Both parties most likely already have this value so it is
            # somewhat redundant to have it here.
            "shyftID": self.shyftID,

            # This next one is specific to P2PKH. Other prover/verifiers will
            # need different data.
            "signature": self.signature,
        }

        return message

    # refer to EIP-191 for more information
    def sign(self, seckey: bytes):
        """
        Really this is just an example of how to make a valid signature for
        this verifier.
        """
        ownership_proof_message = self.make_ownership_proof_message()
        msg = encode_defunct(ownership_proof_message)
        signed_message = w3.eth.account.sign_message(msg, private_key=seckey)
        signature = b2x(signed_message.signature)

        verify = self.verify(signature)
        if not verify:
            raise Exception("Signing failed.")

        return signature

    def verify(self, signature: str):
        """
        Verify something that might be a signature proving ownership of the
        address, based on the reference signing implementation.
        """
        ownership_proof_message = self.make_ownership_proof_message()
        msg = encode_defunct(ownership_proof_message)
        returned_account = w3.eth.account.recover_message(msg, signature=str(signature))
        self._verified = (returned_account.lower() == self.address.lower())
        print("returned_account: ", returned_account)

        if self._verified:
            self.signature = signature

        return self._verified

class EthereumMainnetForwardFactoryOwnership:
    """
    EOA -> contract (create) -> contract (create2)

    Example:
        deposit address: (create2 forwarding contract below)
        EOA -> create forwardingfactory contract
        forwardingfactory contract -> create2 forwarding contract
        (where the forwarding contract might forward to cold storage)

    To prove ownership:
        1) prove ownership of EOA address
        2) provide forwardingfactory contract address and the nonce that was used to create it
        3) provide forwarding contract address and its salt and initCodeHash

    To verify ownership:
        1) verify ownership of EOA address using ECDSA pubkey recovery
        2) calculate forwardingfactory contract address from (EOA address, nonce)
        3) calculate create2 forwarding contract address from (forwarding factory address and other data)
        4) verify that the create2 forwarding contract address equals the expected address

    The last contract can be a forwarder contract that might be forwarding to
    cold storage. To prove ownership, prove ownership of the key that created
    the contract chain. Along the way, prove ownership of the addresses.

    NOTE: Any user can create a forwarder contract and forward to literally
    anywhere. The proof of address ownership here requires that the proof
    verifier also considers the Shyft VASP that produced the proof of ownership
    and whether it seems to be a financial institution, or if the contract is
    forwarding to some other exchange.
    """

    # TODO: define plugin metadata
    _chain = "ETH-mainnet"
    _asset = None # no constraint
    _address_type = "EOA-create-create2"

    def __init__(self, final_contract_address: str, shyftID: str, wire_message: dict):
        self.final_contract_address = final_contract_address
        self.shyftID = shyftID
        self._verified = False
        self.signature = None

        self.construction_chain = []
        if "construction_chain" in wire_message.keys():
            self.construction_chain = wire_message["construction_chain"]
            self.address = self.construction_chain[0]["address"]

        valid = self.is_final_contract_address_valid()
        if not valid:
            raise Exception("Final contract address does not match the given data.")

    def make_ownership_proof_message(self):
        #return make_default_ownership_proof_message(self.shyftID, self.address)
        message = b"I am shyftID=" + bytes(self.shyftID, "ascii") + b" and I own the address " + bytes(str(self.final_contract_address), "ascii")
        return message

    @staticmethod
    def compute_next_address(address, construct):
        if construct["type"] == "create":
            # https://github.com/ethereum/go-ethereum/blob/af02e97929d47238fa0dbd233846270802b99e1a/crypto/crypto.go#L107
            nonce = construct["nonce"]
            address_bytes = ethereum_address_to_bytes(address)
            rlp_encoded = rlp_encode([address_bytes, nonce])
            some_bytes = keccak256(rlp_encoded).digest()
            new_address = ethereum_bytes_to_address(some_bytes[12:])
            return new_address
        elif construct["type"] == "create2":
            # https://github.com/ethereum/go-ethereum/blob/af02e97929d47238fa0dbd233846270802b99e1a/crypto/crypto.go#L114
            salt = x(construct["salt"])
            initCodeHash = x(construct["initCodeHash"])
            address_bytes = ethereum_address_to_bytes(address)
            some_bytes = keccak256(b"\xff" + address_bytes + salt + initCodeHash).digest()
            new_address = ethereum_bytes_to_address(some_bytes[12:])
            return new_address
        else:
            raise Exception("Don't know how to compute the next address.")

    def is_final_contract_address_valid(self):
        """
        This is an important part of verification. Without this verification,
        there would be no proof that the EOA is actually associated with the
        final deposit address.
        """
        chain = self.construction_chain

        if chain[0]["type"] != "EOA":
            raise Exception("Don't know how to handle this contract construction chain.")

        address = chain[0]["address"]

        for construct in chain[1:]:
            address = self.compute_next_address(address, construct)
            print("next address is: ", address)

        return address == self.final_contract_address

    def make_wire_message(self):
        message = {
            "chain": self._chain,
            "asset": self._asset, # not constrained
            "address_type": self._address_type,
            "address": self.final_contract_address,
            "shyftID": self.shyftID,
            "signature": self.signature,
            "construction_chain": self.construction_chain,
        }

        return message

# TODO: note that the verification function should really call
# is_final_contract_address_valid, but it's not because it is assumed to be
# called by the constructor.
EthereumMainnetForwardFactoryOwnership.sign = EthereumMainnetExternallyOwnedAccountOwnership.sign
EthereumMainnetForwardFactoryOwnership.verify = EthereumMainnetExternallyOwnedAccountOwnership.verify

# base class
class MulticryptoMainnetP2PKHAddressOwnership:

    _address_type = "P2PKH"

    def __init__(self, address: str, shyftID: str, wire_message: dict):
        self.address = str(address)
        self.shyftID = shyftID

        # Unlike the bitcoin P2PKH implementation, this will be using ECDSA
        # pubkey recovery to make sure the calculated address is the same as
        # the expected address.

        self._verified = False
        self.signature = None

        #if not self.is_address_valid():
        #    raise Exception("Invalid address.")

    def make_ownership_proof_message(self):
        #return make_default_ownership_proof_message(self.shyftID, self.address)
        message = b"I am shyftID=" + bytes(self.shyftID, "ascii") + b" and I own the address " + bytes(str(self.address), "ascii")
        return str(message, "ascii")

    def make_wire_message(self):
        message = {
            "chain": self._chain,
            "asset": self._asset,
            "address_type": self._address_type,
            "address": self.address,
            "shyftID": self.shyftID,
        }

        if self.signature != None:
            message["signature"] = self.signature

        return message

    def sign(self, wif_private_key):
        message = self.make_ownership_proof_message()
        signature = multicrypto_sign_message(self._COIN_DATA, message, wif_private_key)
        verify = self.verify(signature)
        if not verify:
            raise Exception("Signing failed.")

        return str(signature, "ascii")

    def verify(self, signature: str):
        original_signature = signature

        message = self.make_ownership_proof_message()
        message_with_magic_prefix = monkeypatched_add_magic_prefix(message, self._COIN_DATA)
        message_with_magic_prefix = message_with_magic_prefix.encode()

        decoded_signature_message = base64.b64decode(signature)
        v = decoded_signature_message[0]
        signature = decoded_signature_message[1:]

        # TODO: is this the right size of signature?
        r = int.from_bytes(signature[:32], byteorder="big")
        s = int.from_bytes(signature[32:], byteorder="big")

        verify = multicrypto_verify_message(self._COIN_DATA, message_with_magic_prefix, v, (r, s), self.address)

        if verify == True:
            self.signature = original_signature

        return verify

class ZcashMainnetP2PKHAddressOwnership(MulticryptoMainnetP2PKHAddressOwnership):
    """
    Transparent P2PKH addresses for Zcash. Note that there are also transparent
    P2SH addresses as well, which this module does not support.

    https://zips.z.cash/protocol/protocol.pdf
    """

    _chain = "zcash-mainnet"
    _asset = "ZEC"
    _address_type = "P2PKH"

    _COIN_DATA = multicrypto_coin_data["ZEC"]

# https://www.litecoinpool.org/verifymessage
class LitecoinMainnetP2PKHAddressOwnership(MulticryptoMainnetP2PKHAddressOwnership):
    _chain = "litecoin-mainnet"
    _asset = "LTC"
    _address_type = "P2PKH"
    _COIN_DATA = multicrypto_coin_data["LTC"]

class DogecoinMainnetP2PKHAddressOwnership(MulticryptoMainnetP2PKHAddressOwnership):
    _chain = "dogecoin-mainnet"
    _asset = "DOGE"
    _address_type = "P2PKH"
    _COIN_DATA = multicrypto_coin_data["DOGE"]

# https://explorer.mydashwallet.org/insight/messages/verify
class DashMainnetP2PKHAddressOwnership(MulticryptoMainnetP2PKHAddressOwnership):
    _chain = "dash-mainnet"
    _asset = "DASH"
    _address_type = "P2PKH"
    _COIN_DATA = multicrypto_coin_data["DASH"]

# darkcoin uses different capitalization
# also this is why add_magic_prefix is monkeypatched
DashMainnetP2PKHAddressOwnership._COIN_DATA["name"] = "DarkCoin"
# other capitalizations can be found here:
# https://github.com/trezor/trezor-core/blob/master/src/apps/common/coininfo.py

class BitcoinMainnetP2PKHAddressOwnership:

    _chain = "BTC-mainnet"
    _asset = "BTC"
    _address_type = "P2PKH"

    def __init__(self, address: str, shyftID: str, wire_message: dict):
        self.address = str(address)
        self.pubkey = wire_message["pubkey"] # hex-encoded bytes
        self.shyftID = shyftID
        self._verified = False
        self.signature = None

        if not self.is_address_valid():
            raise Exception("Invalid address.")

    def is_address_valid(self):
        """
        Check that the given pubkey can be used to reconstruct the identical
        address from the blockchain or the forthcoming payment. It is important
        that the address comes from that source (like a withdrawal request
        created by a user) rather than from the counterparty handing over a
        possible signature.
        """
        SelectParams('mainnet')

        scriptPubKey = CScript([OP_DUP, OP_HASH160, Hash160(CPubKey(x(self.pubkey))), OP_EQUALVERIFY, OP_CHECKSIG])
        reconstructed_address = str(CBitcoinAddress.from_scriptPubKey(scriptPubKey))
        if reconstructed_address != self.address:
            return False
        elif reconstructed_address == self.address:
            return True

    def make_ownership_proof_message(self):
        """
        Both the prover and the verifier need to construct the same message
        that they will be proving and verifying on. If the message differs in
        any way, then the proof will fail even if the prover has the secret
        key.
        """
        return make_default_ownership_proof_message(self.shyftID, self.address)

    def make_wire_message(self):
        """
        The prover can use this function to generate a dictionary with
        information for the verifier to select which verifier to use for the
        given address. It also includes the signature.

        Over the wire the format of the message might be string-serialized json
        or some other format.

        While the address type can be guessed in some cases, like P2PKH, it's
        better to just be explicit about it when communicating over the wire.
        """

        # ownership_proof_message can be reconstructed from these details and
        # therefore doesn't need to be sent over the wire.

        message = {
            "chain": self._chain,
            "asset": self._asset,
            "address_type": self._address_type,
            "address": self.address,

            # Both parties most likely already have this value so it is
            # somewhat redundant to have it here.
            "shyftID": self.shyftID,

            # This next one is specific to P2PKH. Other prover/verifiers will
            # need different data.
            "pubkey": self.pubkey,
            "signature": self.signature,
        }

        return message

    def sign(self, seckey: bytes):
        """
        Really this is just an example of how to make a valid signature for
        this verifier. To implement it in exactly the same way, look into the
        implementation of BitcoinMessage and SignMessage because there is an
        invisible-to-you-here message prefix that gets added.
        """
        SelectParams('mainnet')

        # Note that BitcoinMessage prepends some text to the beginning of the
        # message.
        ownership_proof_message = self.make_ownership_proof_message()
        message = BitcoinMessage(ownership_proof_message)
        signature = SignMessage(seckey, message)
        signature = signature.decode("ascii")

        verify = self.verify(signature)
        if not verify:
            raise Exception("Signing failed.")

        return signature

    def verify(self, signature: str):
        """
        Verify something that might be a signature proving ownership of the
        address, based on the reference signing implementation.
        """
        SelectParams('mainnet')

        if not self.is_address_valid():
            raise Exception("Invalid address.")

        # Note that BitcoinMessage prepends some text to the beginning of the
        # message. Also it uses bitcoin's serialization format which includes
        # length:
        # https://bitcoin.stackexchange.com/questions/68844/explicit-message-length-in-bitcoin-signed-message
        ownership_proof_message = self.make_ownership_proof_message()
        verify = VerifyMessage(self.address, BitcoinMessage(ownership_proof_message), signature)
        self._verified = verify

        if verify == True:
            self.signature = signature

        return verify

class BitcoinMainnetP2WPKHAddressOwnership:

    _chain = "BTC-mainnet"
    _asset = "BTC"
    _address_type = "P2WPKH"

    def __init__(self, address: str, shyftID: str, wire_message: dict):
        self.address = str(address)
        self.pubkey = wire_message["pubkey"]
        self.shyftID = shyftID
        self._verified = False
        self.signature = None

        if not self.is_address_valid():
            raise Exception("Invalid address.")

    def is_address_valid(self):
        """
        Check that the given pubkey can be used to reconstruct the identical
        address from the blockchain or the forthcoming payment. It is important
        that the address comes from that source (like a withdrawal request
        created by a user) rather than from the counterparty handing over a
        possible signature.
        """
        SelectParams('mainnet')

        scriptPubKey = CScript([OP_0, Hash160(CPubKey(x(self.pubkey)))])
        reconstructed_address = str(P2WPKHBitcoinAddress.from_scriptPubKey(scriptPubKey))
        if reconstructed_address != self.address:
            return False
        elif reconstructed_address == self.address:
            return True

    def make_ownership_proof_message(self):
        """
        Both the prover and the verifier need to construct the same message
        that they will be proving and verifying on. If the message differs in
        any way, then the proof will fail even if the prover has the secret
        key.
        """
        return make_default_ownership_proof_message(self.shyftID, self.address)

    def make_wire_message(self):
        """
        The prover can use this function to generate a dictionary with
        information for the verifier to select which verifier to use for the
        given address. It also includes the signature.

        Over the wire the format of the message might be string-serialized json
        or some other format.
        """

        # ownership_proof_message can be reconstructed from these details and
        # therefore doesn't need to be sent over the wire.

        message = {
            "chain": self._chain,
            "asset": self._asset,
            "address_type": self._address_type,
            "address": self.address,

            # Both parties most likely already have this value so it is
            # somewhat redundant to have it here.
            "shyftID": self.shyftID,

            # This next one is specific to P2WPKH. Other prover/verifiers will
            # need different data.
            "pubkey": self.pubkey,
            "signature": self.signature,
        }

        return message

    def sign(self, seckey: bytes):
        """
        Really this is just an example of how to make a valid signature for
        this verifier. To implement it in exactly the same way, look into the
        implementation of BitcoinMessage and SignMessage because there is an
        invisible-to-you-here message prefix that gets added.
        """
        SelectParams('mainnet')

        # Note that BitcoinMessage prepends some text to the beginning of the
        # message.
        ownership_proof_message = self.make_ownership_proof_message()
        message = BitcoinMessage(ownership_proof_message)
        signature = SignMessage(seckey, message)
        signature = b2x(signature)

        # Note that using SignMessage here means that the verifier has to (1)
        # check that the pubkey can be used to make the P2WPKH address, and (2)
        # construct a P2PKH address (based on the pubkey) for VerifyMessage.

        verify = self.verify(signature)
        if not verify:
            raise Exception("Signing failed.")

        return signature

    def verify(self, signature: str):
        """
        Verify something that might be a signature proving ownership of the
        address, based on the reference signing implementation.
        """
        SelectParams('mainnet')

        if not self.is_address_valid():
            raise Exception("Invalid address.")

        # VerifyMessage can only use a P2PKH address, thankfully there's a way
        # to convert from P2WPKH to P2PKH. This is only safe because
        # is_address_valid was successful above.
        p2pkh_scriptPubKey = CScript([OP_DUP, OP_HASH160, Hash160(CPubKey(x(self.pubkey))), OP_EQUALVERIFY, OP_CHECKSIG])
        reconstructed_address = str(CBitcoinAddress.from_scriptPubKey(p2pkh_scriptPubKey))

        # Note that BitcoinMessage prepends some text to the beginning of the
        # message.
        ownership_proof_message = self.make_ownership_proof_message()
        verify = VerifyMessage(str(reconstructed_address), BitcoinMessage(ownership_proof_message), x(signature))
        self._verified = verify

        if verify == True:
            self.signature = signature

        return verify

class BitcoinP2SHMixin:
    def __init__(self, address: str, shyftID: str, wire_message: dict):
        self._verified = False
        self.shyftID = shyftID

        # expected address
        self.address = str(address)

        # each pubkey will have a signature
        self.signatures = {}

        self.threshold_size = wire_message["p2sh_multisig_params"]["threshold_size"]
        self.quorum_size = wire_message["p2sh_multisig_params"]["quorum_size"]

        self._threshold_verified = False
        self._quorum_verified = False

        # The public_keys must be given in the order in which they appear in
        # the redeemScript.
        self.public_keys = wire_message["p2sh_multisig_params"]["public_keys"]

        if not self.is_address_valid():
            raise Exception("Invalid address.")

    # TODO: should the ownership message need to change per pubkey?
    def make_ownership_proof_message(self):
        return make_default_ownership_proof_message(self.shyftID, self.address)

    def make_wire_message(self):
        # The wire_message doesn't need to include a redeemScript because there
        # is a specific template that the redeemScript will follow. However,
        # make sure that your implementation of P2SH is using the same template
        # format as expected here, for your address.
        message = {
            "chain": self._chain,
            "asset": self._asset,
            "address_type": self._address_type,

            "address": self.address,
            "shyftID": self.shyftID,

            "p2sh_multisig_params": {
                "threshold_size": int(self.threshold_size),
                "quorum_size": int(self.quorum_size),

                # public_keys should be a list of strings of hex-encoded
                # public keys.
                "public_keys": self.public_keys,
            },

            "signatures": self.signatures,
        }

        return message

    def sign(self, seckey: bytes):
        """
        Generate one of the signatures using one of the secret keys.
        """
        SelectParams('mainnet')

        # Note that BitcoinMessage prepends some text to the beginning of the
        # message.
        ownership_proof_message = self.make_ownership_proof_message()
        message = BitcoinMessage(ownership_proof_message)
        signature = SignMessage(seckey, message)
        signature = b2x(signature)

        # which pubkey does this correspond to?
        pubkey = b2x(CBitcoinSecret.from_secret_bytes(seckey).pub)

        # In this case, we only need a local verification of this signature for
        # this key. The counterparty should be a little more defensive though
        # in the real verify function.
        verify = self.verify_signature_for_pubkey(pubkey, signature)
        if verify:
            self.signatures[pubkey] = signature
        elif not verify:
            raise Exception("Signing failed.")

        return signature

    def verify_signature_for_pubkey(self, pubkey, signature):
        SelectParams('mainnet')

        if not self.is_address_valid():
            raise Exception("Invalid address.")

        if not pubkey in self.public_keys:
            raise Exception("Given pubkey was not used to construct this address.")

        # VerifyMessage expects P2PKH address
        scriptPubKey = CScript([OP_DUP, OP_HASH160, Hash160(CPubKey(x(pubkey))), OP_EQUALVERIFY, OP_CHECKSIG])
        some_address = str(CBitcoinAddress.from_scriptPubKey(scriptPubKey))

        # Note that BitcoinMessage prepends some text to the beginning of the
        # message. Also it uses bitcoin's serialization format which includes
        # length:
        # https://bitcoin.stackexchange.com/questions/68844/explicit-message-length-in-bitcoin-signed-message
        ownership_proof_message = self.make_ownership_proof_message()
        verify = VerifyMessage(some_address, BitcoinMessage(ownership_proof_message), x(signature))
        return verify

    def verify(self, signatures: dict):
        """
        Verify each signature in the dictionary of signatures.

        shape: b2x(pubkey) -> b2x(signature)
        """
        SelectParams('mainnet')

        if not self.is_address_valid():
            raise Exception("Invalid address.")

        ownership_proof_message = self.make_ownership_proof_message()

        verified = 0
        for (given_pubkey, signature) in signatures.items():
            if given_pubkey not in self.public_keys:
                raise Exception("Signature for unexpected public key.")

            # VerifyMessage expects P2PKH address
            scriptPubKey = CScript([OP_DUP, OP_HASH160, Hash160(CPubKey(x(given_pubkey))), OP_EQUALVERIFY, OP_CHECKSIG])
            some_address = str(CBitcoinAddress.from_scriptPubKey(scriptPubKey))

            # verify the signature is valid
            verify = VerifyMessage(some_address, BitcoinMessage(ownership_proof_message), x(signature))
            if verify:
                verified += 1
            else:
                raise Exception("Bad signature detected.")

        if verified >= self.threshold_size:
            self._threshold_verified = True
        else:
            self._threshold_verified = False

        if verified == self.quorum_size:
            self._quorum_verified = True
        else:
            self._quorum_verified = False

        return verified

class BitcoinMainnetP2SHMultisigAddressOwnership(BitcoinP2SHMixin):
    """
    This prover/verifier is only for bitcoin P2SH multisig. This means that
    while a 2-of-3 multisig and 6-of-9 multisig would be usable here, a 2-of-3
    multisig that also has a timelock/HTLC would not be provable nor verifiable
    through this component.

    Another example that would not be provable using this component would be a
    P2SH script that had a redeemScript consisting solely of the pubkey and
    OP_CHECKSIG.
    """

    _chain = "BTC-mainnet"
    _asset = "BTC"
    _address_type = "P2SH-multisig"

    def is_address_valid(self):
        if self.threshold_size == 0:
            raise Exception("Threshold must be greater than zero.")

        if self.quorum_size < self.threshold_size:
            raise Exception("Quorum size can't be smaller than threshold size.")

        if self.threshold_size > 16 or self.quorum_size > 16:
            raise Exception("out of bounds")

        threshold = CScriptOp(0x50 + self.threshold_size)
        quorum = CScriptOp(0x50 + self.quorum_size)

        script_contents = [threshold]
        for public_key in self.public_keys:
            # convert pubkey from hex-encoded string to bytes
            script_contents.append(x(public_key))
        script_contents.append(quorum)
        script_contents.append(OP_CHECKMULTISIG)

        redeemScript = CScript(script_contents)
        scriptPubKey = redeemScript.to_p2sh_scriptPubKey()
        p2sh_address = CBitcoinAddress.from_scriptPubKey(scriptPubKey)

        if str(p2sh_address) == self.address:
            return True
        else:
            return False

class BitcoinMainnetP2WSHMultisigAddressOwnership(BitcoinP2SHMixin):
    """
    This prover/verifier is only for bitcoin P2WSH multisig. This means that
    while a 2-of-3 multisig and 6-of-9 multisig would be usable here, a 2-of-3
    multisig that also has a timelock/HTLC would not be provable nor verifiable
    through this component.

    Another example that would not be provable using this component would be a
    P2WSH script that had a redeemScript consisting solely of the pubkey and
    OP_CHECKSIG.
    """

    _chain = "BTC-mainnet"
    _asset = "BTC"
    _address_type = "P2WSH-multisig"

    def is_address_valid(self):
        if self.threshold_size == 0:
            raise Exception("Threshold must be greater than zero.")

        if self.quorum_size < self.threshold_size:
            raise Exception("Quorum size can't be smaller than threshold size.")

        if self.threshold_size > 16 or self.quorum_size > 16:
            raise Exception("out of bounds")

        threshold = CScriptOp(0x50 + self.threshold_size)
        quorum = CScriptOp(0x50 + self.quorum_size)

        script_contents = [threshold]
        for public_key in self.public_keys:
            # convert pubkey from hex-encoded string to bytes
            script_contents.append(x(public_key))
        script_contents.append(quorum)
        script_contents.append(OP_CHECKMULTISIG)

        redeemScript = CScript(script_contents)
        scriptHash = hashlib.sha256(redeemScript).digest()
        scriptPubKey = CScript([OP_0, scriptHash])
        p2wsh_address = P2WSHBitcoinAddress.from_scriptPubKey(scriptPubKey)

        if str(p2wsh_address) == self.address:
            return True
        else:
            return False

class SolanaAddressOwnership:

    _chain = "solana-mainnet"
    _asset = "SOL"
    _address_type = "publickey"

    # address is like 6QyvUKk3FCzmtF2uuZzb1VeG3nTpAewAToZx6KrQGLtF
    def __init__(self, address: str, shyftID: str, wire_message: dict):
        self._verified = False
        self.signature = None

        self.address = SolanaPublicKey(address)
        self.shyftID = shyftID

    def make_ownership_proof_message(self):
        return make_default_ownership_proof_message(self.shyftID, self.address)

    def make_wire_message(self):
        message = {
            "chain": self._chain,
            "asset": self._asset,
            "address_type": self._address_type,
            "address": str(self.address),

            # Both parties most likely already have this value so it is
            # somewhat redundant to have it here.
            "shyftID": self.shyftID,

            "signature": self.signature,
        }

        return message

    def sign(self, seckey: bytes):
        account = SolanaAccount(seckey)

        if str(account.public_key()) != str(self.address):
            raise Exception(f"Signing key does not match Solana address {self.address}")

        ownership_proof_message = self.make_ownership_proof_message()
        ownership_proof_message = x(ownership_proof_message) # need bytes

        signed_message = account.sign(ownership_proof_message)
        signature = signed_message.signature.hex()

        verify = self.verify(signature)
        if not verify:
            raise Exception("Signing failed.")

        return signature

    def verify(self, signature: str):
        ownership_proof_message = self.make_ownership_proof_message()

        # need bytes
        original_signature = signature
        signature = x(signature)
        ownership_proof_message = x(ownership_proof_message)

        verify_key = nacl.signing.VerifyKey(bytes(self.address))
        message = verify_key.verify(ownership_proof_message, signature)

        if message == ownership_proof_message:
            self._verified = True
            self.signature = original_signature
        else:
            self._verified = False

        return self._verified

# register all the plugins here
ADDRESS_TYPE_REGISTRY = [
    BitcoinMainnetP2PKHAddressOwnership,
    BitcoinMainnetP2WPKHAddressOwnership,
    BitcoinMainnetP2SHMultisigAddressOwnership,
    BitcoinMainnetP2WSHMultisigAddressOwnership,
    EthereumMainnetExternallyOwnedAccountOwnership,
    EthereumMainnetForwardFactoryOwnership,
    MoneroAddressOwnership,
    ZcashMainnetP2PKHAddressOwnership,
    LitecoinMainnetP2PKHAddressOwnership,
    DogecoinMainnetP2PKHAddressOwnership,
    DashMainnetP2PKHAddressOwnership,
    SolanaAddressOwnership,
]

def find_plugin_for(wire_message):
    """
    A wire_message is received over IVMS101 or some other means. The unverified
    party makes a message containing some information that can be used by this
    function to find the appropriate verifier for what the unverified party
    says the address type is.
    """
    (chain, asset, address_type) = (wire_message["chain"], wire_message["asset"], wire_message["address_type"])
    found = []
    for plugin in ADDRESS_TYPE_REGISTRY:
        if plugin._chain == chain and (plugin._asset == None or plugin._asset == asset) and plugin._address_type == address_type:
            found.append(plugin)
    if len(found) == 0:
        raise Exception("Unable to find a plugin for this address type.")
    elif len(found) > 1:
        raise Exception("Multiple matching plugins found, and this shouldn't happen.")
    else:
        return found[0]

def test_bitcoin_p2pkh():
    secret = hashlib.sha256(b'correct horse battery staple').digest()
    seckey = CBitcoinSecret.from_secret_bytes(secret)
    pubkey = seckey.pub
    scriptPubKey = CScript([OP_DUP, OP_HASH160, Hash160(pubkey), OP_EQUALVERIFY, OP_CHECKSIG])
    address = CBitcoinAddress.from_scriptPubKey(scriptPubKey)
    #address = str(address)

    owner_shyftID = "feedbeef"
    serialized_address = str(address)
    serialized_pubkey = b2x(bytes(pubkey))

    # **** prover ****

    # As the address owner, make a proof of address ownership.
    mock_wire_message = {"pubkey": serialized_pubkey}
    prover = BitcoinMainnetP2PKHAddressOwnership(serialized_address, owner_shyftID, mock_wire_message)
    signature = prover.sign(seckey)
    wire_message = prover.make_wire_message()

    # **** verifier ****

    # As the address ownership verifier, find the right plugin and check that
    # the signature is valid.
    plugin = find_plugin_for(wire_message)

    # Get the shyftID from the asserting prover. It could be in wire_message
    # but based on Veriscope protocol the verifier likely has the value from
    # another source anyway.
    asserting_owner_shyftID = owner_shyftID

    # It's important to get the expected address from a user's withdrawal
    # request, and not from the prover. It should match the value from the
    # prover but it's not safe to use an address given by the prover as input.
    expected_address = str(address)

    verifier = plugin(expected_address, asserting_owner_shyftID, wire_message)
    verify = verifier.verify(wire_message["signature"])
    print("P2PKH verification result: " + str(verify))

def test_bitcoin_p2sh_multisig():
    print("--------")
    print("Testing bitcoin p2sh multisig....")

    owner_shyftID = "feedbeef"

    secret_keys = [CBitcoinSecret.from_secret_bytes(hashlib.sha256(b"correct horse battery staple " + int(x).to_bytes(1, "big")).digest()) for x in range(0, 3)]
    pubkeys = [b2x(seckey.pub) for seckey in secret_keys]
    address = "3QKAsZYJggEcKdbnSKgYQusb7mFrjWhhAD"

    wire_message = {
        "p2sh_multisig_params": {
            "threshold_size": 2,
            "quorum_size": 3,
            "public_keys": pubkeys,
        }
    }

    # **** prover ****
    prover = BitcoinMainnetP2SHMultisigAddressOwnership(address, owner_shyftID, wire_message)
    signatures = {b2x(CBitcoinSecret.from_secret_bytes(secret_key).pub): prover.sign(secret_key) for secret_key in secret_keys}
    wire_message = prover.make_wire_message()

    # **** verifier ****
    plugin = find_plugin_for(wire_message)
    asserting_owner_shyftID = owner_shyftID
    expected_address = address
    verifier = plugin(expected_address, asserting_owner_shyftID, wire_message)
    verify = verifier.verify(wire_message["signatures"])
    if verify == 0:
        raise Exception("Failed to verify bitcoin p2sh multisig.")
    print("Bitcoin p2sh multisig verification result: " + str(verify))

def test_bitcoin_p2wsh_multisig():
    print("--------")
    print("Testing bitcoin p2wsh multisig....")

    owner_shyftID = "feedbeef"

    secret_keys = [CBitcoinSecret.from_secret_bytes(hashlib.sha256(b"correct horse battery staple " + int(x).to_bytes(1, "big")).digest()) for x in range(0, 3)]
    pubkeys = [b2x(seckey.pub) for seckey in secret_keys]
    address = "bc1quktan9at2lfd6v6jp6073phchz3jyax7m4q06c7lcw2z4ptvfznspmd2en"

    wire_message = {
        "p2sh_multisig_params": {
            "threshold_size": 2,
            "quorum_size": 3,
            "public_keys": pubkeys,
        }
    }

    # **** prover ****
    prover = BitcoinMainnetP2WSHMultisigAddressOwnership(address, owner_shyftID, wire_message)
    # for testing only a subset of signers...
    #secret_keys = secret_keys[:1]
    signatures = {b2x(CBitcoinSecret.from_secret_bytes(secret_key).pub): prover.sign(secret_key) for secret_key in secret_keys}
    wire_message = prover.make_wire_message()

    # **** verifier ****
    plugin = find_plugin_for(wire_message)
    asserting_owner_shyftID = owner_shyftID
    expected_address = address
    verifier = plugin(expected_address, asserting_owner_shyftID, wire_message)
    verify = verifier.verify(wire_message["signatures"])
    if verify == 0:
        raise Exception("Failed to verify bitcoin p2wsh multisig.")
    print("Bitcoin p2wsh multisig verification result: " + str(verify))

def test_bitcoin_p2wpkh():
    secret = hashlib.sha256(b'correct horse battery staple').digest()
    seckey = CBitcoinSecret.from_secret_bytes(secret)
    pubkey = seckey.pub
    scriptPubKey = CScript([OP_0, Hash160(pubkey)])
    address = P2WPKHBitcoinAddress.from_scriptPubKey(scriptPubKey)
    #address = str(address)

    owner_shyftID = "feedbeef"
    serialized_address = str(address)
    serialized_pubkey = b2x(bytes(pubkey))

    # **** prover ****

    # As the address owner, make a proof of address ownership.
    mock_wire_message = {"pubkey": serialized_pubkey}
    prover = BitcoinMainnetP2WPKHAddressOwnership(serialized_address, owner_shyftID, mock_wire_message)
    signature = prover.sign(seckey)
    wire_message = prover.make_wire_message()

    # **** verifier ****

    # As the address ownership verifier, find the right plugin and check that
    # the signature is valid.
    plugin = find_plugin_for(wire_message)

    # Get the shyftID from the asserting prover. It could be in wire_message
    # but based on Veriscope protocol the verifier likely has the value from
    # another source anyway.
    asserting_owner_shyftID = owner_shyftID

    # It's important to get the expected address from a user's withdrawal
    # request, and not from the prover. It should match the value from the
    # prover but it's not safe to use an address given by the prover as input.
    expected_address = str(address)

    verifier = plugin(expected_address, asserting_owner_shyftID, wire_message)
    verify = verifier.verify(wire_message["signature"])
    print("P2WPKH verification result: " + str(verify))

def test_solana():
    owner_shyftID = "feedbeef"
    secret_key = hashlib.sha256(b'correct horse battery staple').digest()
    account = SolanaAccount(secret_key)
    address = str(account.public_key())

    # **** prover ****
    prover = SolanaAddressOwnership(address, owner_shyftID, None)
    signature = prover.sign(secret_key)
    wire_message = prover.make_wire_message()

    # **** verifier ****
    plugin = find_plugin_for(wire_message)
    asserting_owner_shyftID = owner_shyftID
    expected_address = str(address)

    verifier = plugin(expected_address, asserting_owner_shyftID, wire_message)
    verify = verifier.verify(wire_message["signature"])
    print("Solana verification result: " + str(verify))

def test_eth_eoa():
    seckey = b"\xb2\\}\xb3\x1f\xee\xd9\x12''\xbf\t9\xdcv\x9a\x96VK-\xe4\xc4rm\x03[6\xec\xf1\xe5\xb3d"
    account = "0x5ce9454909639D2D17A3F753ce7d93fa0b9aB12E"

    owner_shyftID = "feedbeef"

    # **** prover ****
    prover = EthereumMainnetExternallyOwnedAccountOwnership(account, owner_shyftID, None)
    signature = prover.sign(seckey)
    wire_message = prover.make_wire_message()

    # *** verifier ***
    plugin = find_plugin_for(wire_message)
    asserting_owner_shyftID = owner_shyftID
    expected_account = account
    verifier = plugin(expected_account, asserting_owner_shyftID, wire_message)
    verify = verifier.verify(wire_message["signature"])
    print("EOA verification result: " + str(verify))

def test_eth_eoa_again():
    seckey = hashlib.sha256(b'correct horse battery staple').digest()
    #account = "0xDCCD62d450c645f6437680b8A4DaA098396DcE0e"
    account = w3.eth.account.from_key(seckey).address

    owner_shyftID = "feedbeef"

    # **** prover ****
    prover = EthereumMainnetExternallyOwnedAccountOwnership(account, owner_shyftID, None)
    signature = prover.sign(seckey)
    wire_message = prover.make_wire_message()

    # *** verifier ***
    plugin = find_plugin_for(wire_message)
    asserting_owner_shyftID = owner_shyftID
    expected_account = account
    verifier = plugin(expected_account, asserting_owner_shyftID, wire_message)
    verify = verifier.verify(wire_message["signature"])
    print("EOA verification result: " + str(verify))

def test_ethereum_forwardfactory():
    print("--------")
    print("Testing ethereum forward factory prover....")

    owner_shyftID = "feedbeef"
    secret_key = x("b27f6a4cd469531aaee1fb0b7f42c19aacad9cec91dd1b1a3638661c54237a94")

    final_contract_address = "0xef936a7a75459558f74bd2c1668b3b7ec117a569".lower()
    wire_message = {
        "construction_chain": [
            {"type": "EOA", "address": "0xE4096C28e03E3F63b5031f7386bC33C22700235C".lower()},
            {"type": "create", "address": "0x9b970276c8c3d0c139b9a4816c1c74378959a21d".lower(), "nonce": 202},
            {
                "type": "create2",
                "address": "0x9c99cf7a842895a2d1ce97cd62968201f2fbfc09".lower(),
                "salt": "14e26bf8489b5ecf8bed66029345a1fbfce9aba797dee64db4bd6403515916db",
                #"initCode": "e1ff57d23b4c1ca46465adf1461f25da5ff8aa2bc35697d7bfddfc013e655a3a0ca0355395766dd0dedb8f53a613dbc6f581f40fe0083a",
                "initCodeHash": "b80314a8509b53b37509efc64cd733f5c99098da74b63c2fc38e3b2adacadfec",
            },
        ]
    }

    # **** prover ****
    prover = EthereumMainnetForwardFactoryOwnership(final_contract_address=final_contract_address, shyftID=owner_shyftID, wire_message=wire_message)
    prover.sign(secret_key)
    wire_message = prover.make_wire_message()
    print("wire_message: ", wire_message)

    # **** verifier ****
    plugin = find_plugin_for(wire_message)
    asserting_owner_shyftID = owner_shyftID
    deposit_address = final_contract_address
    verifier = plugin(deposit_address, asserting_owner_shyftID, wire_message)
    verify = verifier.verify(wire_message["signature"])
    print("Ethereum ForwardFactory result: " + str(verify))

def test_monero():
    private_spend_key = "19affbe45390661f75b97ccc4990d9aa0fccd206e467dfabd35f96ce7c3ca50c"
    address = "44ZSbn2e8e1hmmJ62YqJzfUj12D65SDrS3ygeLXgWxkmEiRqisAEwcrUcHguE6bdC1Mb1zd2tDDgK6hLFpHc4qyrVbHAaa2"
    owner_shyftID = "feedbeef"

    # **** prover ****
    prover = MoneroAddressOwnership(address, owner_shyftID, None)
    signature = prover.sign(private_spend_key)
    wire_message = prover.make_wire_message()

    # **** verifier ****
    plugin = find_plugin_for(wire_message)
    asserting_owner_shyftID = owner_shyftID
    expected_address = address
    verifier = plugin(expected_address, asserting_owner_shyftID, wire_message)
    verify = verifier.verify(wire_message["signature"])
    print("XMR verification result: " + str(verify))

def test_multicrypto_p2pkh_for_coin(expected_plugin, wif_private_key=None):
    coin_name = expected_plugin._COIN_DATA["name"]
    print("--------")
    print(f"Testing {coin_name} address ownership proofs (P2PKH)")

    secret_prefix_bytes = expected_plugin._COIN_DATA["secret_prefix_bytes"]
    address_prefix_bytes = expected_plugin._COIN_DATA["address_prefix_bytes"]
    owner_shyftID = "feedbeef"

    secret_key = hashlib.sha256(b"correct horse battery staple").digest()
    secret_key = int.from_bytes(secret_key, byteorder="big")
    if not wif_private_key:
        wif_private_key = convert_private_key_to_wif_format(secret_key, secret_prefix_bytes, compressed=True)
    address = convert_wif_private_key_to_address(wif_private_key, address_prefix_bytes, segwit=False)
    print("wif_private_key: ", wif_private_key)
    print("address: ", address)
    # Note that this address is using P2PKH of the compressed public key, not
    # the uncompressed public key.

    # **** prover ****
    prover = expected_plugin(address, owner_shyftID, None)
    signature = prover.sign(wif_private_key)
    wire_message = prover.make_wire_message()
    print("message: ", prover.make_ownership_proof_message())
    print("signature: ", signature)
    print("wire_message = ", wire_message)

    # **** verifier ****
    plugin = find_plugin_for(wire_message)
    asserting_owner_shyftID = owner_shyftID
    expected_address = address
    verifier = plugin(expected_address, asserting_owner_shyftID, wire_message)
    verify = verifier.verify(wire_message["signature"])
    print(f"{coin_name} P2PKH verification result: " + str(verify))

def test_zcash_p2pkh():
    expected_plugin = ZcashMainnetP2PKHAddressOwnership
    result = test_multicrypto_p2pkh_for_coin(expected_plugin)
    return result

def test_litecoin_p2pkh():
    expected_plugin = LitecoinMainnetP2PKHAddressOwnership
    result = test_multicrypto_p2pkh_for_coin(expected_plugin)

    # correct horse battery staple
    # uncompressed P2PKH: LdAPi7uXrLLmeh7u57pzkZc3KovxEDYRJq
    # compressed P2PKH: LWLwtfycqf1uFqypLAug36W4kdgNwrZdNs

    return result

def test_dogecoin_p2pkh():
    expected_plugin = DogecoinMainnetP2PKHAddressOwnership
    result = test_multicrypto_p2pkh_for_coin(expected_plugin)
    # correct horse battery staple
    # WIF private key: QVD3x1RPiWPvyxbTsfxVwaYLyeBZrQvjhZ2aZJUsbuRgsEAGpNQ2
    # address: DGG6AicS4Qg8Y3UFtcuwJqbuRZ3Q7WtYXv
    return result

def test_dash_p2pkh():
    expected_plugin = DashMainnetP2PKHAddressOwnership
    result = test_multicrypto_p2pkh_for_coin(expected_plugin)
    return result

def test_eth_eoa_shyft(account_address, private_key):
    print(f"ETH EOA for account={account_address}")
    seckey = x(private_key)
    account = account_address

    owner_shyftID = "feedbeef"

    # **** prover ****
    prover = EthereumMainnetExternallyOwnedAccountOwnership(account, owner_shyftID, None)
    signature = prover.sign(seckey)
    wire_message = prover.make_wire_message()
    print("wire_message = ", json.dumps(wire_message))

    # *** verifier ***
    plugin = find_plugin_for(wire_message)
    asserting_owner_shyftID = owner_shyftID
    expected_account = account
    verifier = plugin(expected_account, asserting_owner_shyftID, wire_message)
    verify = verifier.verify(wire_message["signature"])
    print("EOA verification result: " + str(verify))

def test_monero_shyft(address, private_spend_key):
    print(f"Monero for address={address}")
    owner_shyftID = "feedbeef"

    # **** prover ****
    prover = MoneroAddressOwnership(address, owner_shyftID, None)
    signature = prover.sign(private_spend_key)
    wire_message = prover.make_wire_message()
    print("wire_message = ", json.dumps(wire_message))

    # **** verifier ****
    plugin = find_plugin_for(wire_message)
    asserting_owner_shyftID = owner_shyftID
    expected_address = address
    verifier = plugin(expected_address, asserting_owner_shyftID, wire_message)
    verify = verifier.verify(wire_message["signature"])
    print("XMR verification result: " + str(verify))

def test_bitcoin_p2pkh_shyft(address, wif_private_key):
    print(f"Bitcoin for address={address}")
    seckey = CBitcoinSecret(wif_private_key)
    pubkey = seckey.pub
    scriptPubKey = CScript([OP_DUP, OP_HASH160, Hash160(pubkey), OP_EQUALVERIFY, OP_CHECKSIG])
    address = CBitcoinAddress.from_scriptPubKey(scriptPubKey)
    #address = str(address)

    owner_shyftID = "feedbeef"
    serialized_address = str(address)
    serialized_pubkey = b2x(bytes(pubkey))

    # **** prover ****

    mock_wire_message = {"pubkey": serialized_pubkey}
    prover = BitcoinMainnetP2PKHAddressOwnership(serialized_address, owner_shyftID, mock_wire_message)
    signature = prover.sign(seckey)
    wire_message = prover.make_wire_message()
    print("wire_message = ", wire_message)

    # **** verifier ****

    plugin = find_plugin_for(wire_message)
    asserting_owner_shyftID = owner_shyftID
    expected_address = str(address)

    verifier = plugin(expected_address, asserting_owner_shyftID, wire_message)
    verify = verifier.verify(wire_message["signature"])
    print("P2PKH verification result: " + str(verify))

def test_zcash_shyft(wif_private_key):
    expected_plugin = ZcashMainnetP2PKHAddressOwnership
    result = test_multicrypto_p2pkh_for_coin(expected_plugin, wif_private_key=wif_private_key)
    return result

# The test_*_shyft() functions are for generating proofs for the addresses and
# secrets provided by veriscope for testing purposes. A few of their secrets
# are in WIF format and need to be converted, which isn't implemented in the
# non-shyft test functions.

if __name__ == "__main__":
    test_bitcoin_p2pkh()
    test_bitcoin_p2wpkh()
    test_bitcoin_p2sh_multisig()
    test_bitcoin_p2wsh_multisig()
    test_eth_eoa()
    test_eth_eoa_again()
    test_ethereum_forwardfactory()
    test_monero()
    test_zcash_p2pkh()
    test_litecoin_p2pkh()
    test_dogecoin_p2pkh()
    test_dash_p2pkh()
    test_solana()
